#!/bin/bash

sleep 2

start_time=`date +'%F %T' -d '5 minutes ago'`
end_time=`date +'%F %T'`

echo $start_time
echo $end_time



data=`tccli cdn DescribeCdnData --StartTime "$start_time" --EndTime "$end_time" --Metric request | jq '.Data[0].CdnData[0].DetailData'`

echo $data | jq '. | length'
request_num=`echo $data | jq .[-1].Value`
echo $request_num
