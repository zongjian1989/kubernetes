#!/bin/bash

nohup /usr/local/prometheus/prometheus &>> /usr/local/prometheus/prometheus.log &
