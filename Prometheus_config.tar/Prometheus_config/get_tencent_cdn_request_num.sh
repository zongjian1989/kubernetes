#!/bin/bash

PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/root/bin:$PATH

sleep 15

start_time=`date +'%F %T' -d '5 minutes ago'`
end_time=`date +'%F %T'`

echo $start_time
echo $end_time

result=`tccli cdn DescribeCdnData --cli-unfold-argument --StartTime "$start_time" --EndTime "$end_time" --Metric request --Domains captive.samsungconnectivity.com --Project 0 2> /dev/null`

rt_code=$?

i=0

while [ $rt_code -ne 0 -a $i -lt 5 ]
do
        sleep 2
        result=`tccli cdn DescribeCdnData --cli-unfold-argument --StartTime "$start_time" --EndTime "$end_time" --Metric request --Domains captive.samsungconnectivity.com --Project 0 2>/dev/null`
        rt_code=$?
        i=$(($i+1))
done

if [ $rt_code -ne 0 ];then
	curl -X DELETE http://192.168.10.4:9091/metrics/job/tencent_cdn/instance/192.168.10.4/domain/captive.samsungconnectivity.com
        exit 0
fi

declare -i request_num

request_num=`echo $result | jq '.Data[0].CdnData[].DetailData[-1].Value'`

echo "`date +%T` $request_num" >> /root/myfiles/request_num.log
# echo "tencent_cdn_request_num $request_num" | curl --data-binary @- http://192.168.10.4:9091/metrics/job/tencent_cdn_request_num/instance/192.168.10.4/domain/captive.samsungconnectivity.com
cat << EOF | curl --data-binary @- http://192.168.10.4:9091/metrics/job/tencent_cdn/instance/192.168.10.4/domain/captive.samsungconnectivity.com
#TYPE tencent_cdn_request_num gauge
tencent_cdn_request_num $request_num
EOF
