#!/bin/bash

sleep 5

start_time=`date +'%F %T' -d '5 minutes ago'`
end_time=`date +'%F %T'`

echo $start_time
echo $end_time

declare -i request_num

request_num=`tccli cdn DescribeCdnData --StartTime "$start_time" --EndTime "$end_time" --Metric request | jq .Data[0].CdnData[0].DetailData[-1].Value`

i=0

while [ "$request_num" -eq "0" -a "$i" -lt 3 ];do
        sleep 2
        request_num=`tccli cdn DescribeCdnData --StartTime "$start_time" --EndTime "$end_time" --Metric request | jq .Data[0].CdnData[0].DetailData[-1].Value`
        i=$(($i+1))
done

echo $request_num >> /root/myfiles/request_num.log
